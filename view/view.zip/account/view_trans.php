<div class="container">
    <div class="jumbotron">
        <h2><?php print $profile_welcome_txt ?></h2>
        <p><?php print $profile_sub_txt ?></p>
    </div>
</div>