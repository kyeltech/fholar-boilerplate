<div class="card border-0 p-4">
    <div class="card-body ">
        <h5>Update Security</h5>
        <hr class="underline mb-4" />
        <div id="response"></div>
        <form method="POST" id="newProductForm">
            <div class="form-group row">
                <div class="col-md-6 grid-stack">
                    <input type="password" class="form-control" value="" name="cur_pas" placeholder="Current Password" required />
                </div>
                <div class="col-md-6">
                    <input type="password" class="form-control" value="" name="new_pass" placeholder="New Password" required />
                </div>
            </div>
            
            <div class="form-group row">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary float-right">Updaet Password</button>
                </div>
            </div>
        </form>
    </div>
</div>